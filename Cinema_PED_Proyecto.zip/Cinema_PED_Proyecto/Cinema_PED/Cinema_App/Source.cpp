#include "Cinema.h"

int main()
{
	Cinema miCine;
	miCine.LeeryCopiarAdmin();
	miCine.LeeryCopiarMovie();
	miCine.LeeryCopiarSalaHora();
	miCine.LeeryCopiarUsu();
	miCine.LeeryCopiarArch();
	miCine.Menu();
	return 0;
}